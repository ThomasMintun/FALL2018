import csv
import sys

def convolve(image, kernel):
	image_h = len(image)
	image_w = len(image[1])
	kernel_h = len(kernel)
	kernel_w = len(kernel[1])

	h = kernel_h//2#floor of dividing by 2
	w = kernel_w//2

	for i in range(h, image_h-h):
		for j in range(w, image_w-w):
			sum = 0

			for m in range(kernel_h):
				for n in range(kernel_w):
					if (0 <= (i-h+m) <= image_h) and (0 <= (j-w+m) <= image_w):
						sum = sum + kernel[m][n]*image[i-h+m][j-w+m]

			image[i][j] = sum/(kernel_w * kernel_h)

file = open('channel2.csv', 'r')
data_reader = csv.reader(file, delimiter=",")
image = []

for row in data_reader:
	image.append(row)
for i in range(len(image)):
	for j in range(len(image[i])):
		image[i][j] = float(image[i][j])
		image[i][j] = int(image[i][j])

print (image)

kernelIdentity = [
	[0, 0, 0],
	[0, 1, 0],
	[0, 0, 0]
]

kernelEdge = [
	[1, 0, -1],
	[0, 0, 0],
	[-1, 0, 1]
]

kernelEdge2 = [
	[0, 1, 0],
	[1, -4, 1],
	[0, -1, 0]
]

kernelEdge3 = [
	[-1, -1, -1],
	[-1, 8, -1],
	[-1, -1, -1]
]

kernelSharpen = [
	[0, -1, 0],
	[-1, 5, -1],
	[0, -1, 0]
]

kernelBoxBlur = [
	[1/9, 1/9, 1/9],
	[1/9, 1/9, 1/9],
	[1/9, 1/9, 1/9]
]

kernelGaussian3x3 = [
	[1/16, 2/16, 1/16],
	[2/16, 4/16, 1/16],
	[1/16, 2/16, 1/16]
]

kernelGaussian5x5 = [
	[1/256, 4/256, 6/256, 4/256, 1/256],
	[4/256, 16/256, 24/256, 16/256, 4/256],
	[6/256, 24/256, 36/256, 24/256, 6/256],
	[4/256, 16/256, 24/256, 16/256, 4/256],
	[1/256, 4/256, 6/256, 4/256, 1/256]
]

kernelGaussianUnsharp5x5 = [
	[-1/256, -4/256, -6/256, -4/256, -1/256],
	[-4/256, -16/256, -24/256, -16/256, -4/256],
	[-6/256, -24/256, -476/256, -24/256, -6/256],
	[-4/256, -16/256, -24/256, -16/256, -4/256],
	[-1/256, -4/256, -6/256, -4/256, -1/256]
]

convolve(image, kernelGaussianUnsharp5x5)
convolve(image, kernelGaussianUnsharp5x5)

with open("convolvedImage.csv", "w",newline = '') as f:
	writer = csv.writer(f)
	writer.writerows(image)